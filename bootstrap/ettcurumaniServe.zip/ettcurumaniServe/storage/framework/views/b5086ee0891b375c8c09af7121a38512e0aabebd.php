<p>Novedad Nueva, Via: ETT Curumani App</p>
<ul>
    <li>Nombre: <?php echo e($name); ?></li>
    <li>Email: <?php echo e($mail); ?> </li>
    <li>Asunto: <?php echo e($asunto); ?></li>
    <li>Descripcion: <?php echo e($novedad); ?></li>
</ul>
