Estimado { solicitud->nombre },<br><br><br>
Su solicitud para el servicio de grúa fue recibida. De inmediato lo contactaremos al número { $solicitud->celular }.
