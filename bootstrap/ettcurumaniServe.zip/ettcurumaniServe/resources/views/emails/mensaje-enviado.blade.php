<p>Novedad Nueva, Via: ETT Curumani App</p>
<ul>
    <li>Nombre: {{$name}}</li>
    <li>Email: {{$mail}} </li>
    <li>Asunto: {{$asunto}}</li>
    <li>Descripcion: {{$novedad}}</li>
</ul>
